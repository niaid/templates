
### Templates
You can find the standard header and footer (html and css) for NIH/NIAID applications
If you have any questions and comments contact us: 
scienceapps@niaid.nih.gov